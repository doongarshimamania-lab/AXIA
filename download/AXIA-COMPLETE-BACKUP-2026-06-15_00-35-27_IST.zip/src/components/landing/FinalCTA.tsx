import { motion } from "framer-motion";
import { WaitlistForm } from "./WaitlistForm";

export function FinalCTA() {
  return (
    <section 
      data-waitlist-section
      className="py-8 px-6 md:px-10 bg-[#00246B] dark:bg-slate-900 relative overflow-hidden"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-15 pointer-events-none">
        <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-white blur-3xl" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 rounded-full bg-blue-400 blur-3xl" />
      </div>

      <div className="max-w-[800px] mx-auto relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4" style={{ fontFamily: "Space Grotesk" }}>
            Protect Your Income Today
          </h2>
          
          <p className="text-lg text-blue-100 mb-6 max-w-2xl mx-auto leading-relaxed">
            Join the waitlist to get early access to the only tool that verifies your work context against platform requirements—before you submit.
          </p>

          <div className="flex justify-center">
            <WaitlistForm 
              variant="dark" 
              ctaText="Get Early Access" 
              showScarcity={true}
              className="bg-white/10 backdrop-blur-sm p-2 rounded-2xl border border-white/10"
            />
          </div>
          
          <p className="mt-6 text-sm text-blue-200/60">
            Join 2,000+ agencies on the waitlist. Launching soon.
          </p>
        </motion.div>
      </div>
    </section>
  );
}