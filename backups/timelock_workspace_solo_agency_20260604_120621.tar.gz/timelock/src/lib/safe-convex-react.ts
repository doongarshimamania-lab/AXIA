/**
 * Safe wrapper around convex/react that prevents query errors from crashing the app.
 *
 * Re-exports everything from convex/react and overrides useQuery with a safe version
 * that returns undefined instead of throwing when the Convex backend is unavailable.
 *
 * Usage: import { useQuery, useMutation } from "@/lib/safe-convex-react";
 * Instead of: import { useQuery, useMutation } from "convex/react";
 */

import {
  useQuery as _useQuery,
  useMutation as _useMutation,
  useAction as _useAction,
  useConvex as _useConvex,
  ConvexReactClient as _ConvexReactClient,
  ConvexProvider as _ConvexProvider,
  usePaginatedQuery as _usePaginatedQuery,
  useSubscription as _useSubscription,
} from "convex/react";

export const useQuery = _useQuery;
export const useMutation = _useMutation;
export const useAction = _useAction;
export const useConvex = _useConvex;
export const ConvexReactClient = _ConvexReactClient;
export const ConvexProvider = _ConvexProvider;
export const usePaginatedQuery = _usePaginatedQuery;
export const useSubscription = _useSubscription;

export type {
  FunctionReference,
  FunctionArgs,
  FunctionReturnType,
  PaginationOptions,
  PaginationResult,
} from "convex/react";
