import { useCallback, useMemo, createContext, useContext, useState, useEffect } from "react";
import type { ReactNode } from "react";

// ─── Types ────────────────────────────────────────────────────
export type WorkspaceType = "personal" | "team";
export type WorkspaceRole = "owner" | "manager" | "member";
export type AccountMode = "solo" | "team";

export interface WorkspaceInfo {
  _id: string;
  name: string;
  type: WorkspaceType;
  description?: string;
  membership?: { role: WorkspaceRole };
}

export interface WorkspaceContext {
  activeWorkspace: WorkspaceInfo | null;
  workspaces: WorkspaceInfo[];
  role: WorkspaceRole | null;
  accountMode: AccountMode;
  isTeamMode: boolean;
  isSoloMode: boolean;
  isOwner: boolean;
  isManager: boolean;
  isMember: boolean;
  canManageTeam: boolean;
  canManageBilling: boolean;
  activeWorkspaceId: string | null;
  isLoading: boolean;
  isAvailable: boolean;
  setAccountMode: (mode: AccountMode) => void;
  switchToWorkspace: (workspaceId: string) => void;
  createTeamWorkspace: (name: string, description?: string) => void;
  upgradeToTeam: () => void;
}

// ─── Local storage keys ──────────────────────────────────────
const STORAGE_KEY_MODE = "axia_account_mode";
const STORAGE_KEY_WORKSPACES = "axia_workspaces";
const STORAGE_KEY_ACTIVE_WS = "axia_active_workspace";

// Default solo workspace
const DEFAULT_SOLO_WORKSPACE: WorkspaceInfo = {
  _id: "ws_solo_default",
  name: "My Workspace",
  type: "personal",
  description: "Your personal freelancer workspace",
  membership: { role: "owner" },
};

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const stored = localStorage.getItem(key);
    if (stored) return JSON.parse(stored);
  } catch {}
  return fallback;
}

function saveToStorage(key: string, value: any) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {}
}

const WorkspaceCtx = createContext<WorkspaceContext>({
  activeWorkspace: DEFAULT_SOLO_WORKSPACE,
  workspaces: [DEFAULT_SOLO_WORKSPACE],
  role: "owner",
  accountMode: "solo",
  isTeamMode: false,
  isSoloMode: true,
  isOwner: true,
  isManager: true,
  isMember: true,
  canManageTeam: true,
  canManageBilling: true,
  activeWorkspaceId: "ws_solo_default",
  isLoading: false,
  isAvailable: true,
  setAccountMode: () => {},
  switchToWorkspace: () => {},
  createTeamWorkspace: () => {},
  upgradeToTeam: () => {},
});

export function useWorkspaceContext() {
  return useContext(WorkspaceCtx);
}

// ─── Provider Component ───────────────────────────────────────
// Uses localStorage for workspace state so it works without auth.
// Convex queries are NOT called here because the workspace tables
// haven't been deployed to Convex yet. When they are, we can add
// safe query hooks back.

export function WorkspaceProvider({ children }: { children: ReactNode }) {
  const [accountMode, setAccountModeState] = useState<AccountMode>(
    loadFromStorage(STORAGE_KEY_MODE, "solo")
  );
  const [workspaces, setWorkspaces] = useState<WorkspaceInfo[]>(
    loadFromStorage(STORAGE_KEY_WORKSPACES, [DEFAULT_SOLO_WORKSPACE])
  );
  const [activeWorkspaceId, setActiveWorkspaceId] = useState<string>(
    loadFromStorage(STORAGE_KEY_ACTIVE_WS, DEFAULT_SOLO_WORKSPACE._id)
  );

  const activeWorkspace = useMemo(() => {
    return workspaces.find(ws => ws._id === activeWorkspaceId) || workspaces[0] || DEFAULT_SOLO_WORKSPACE;
  }, [workspaces, activeWorkspaceId]);

  const role = activeWorkspace?.membership?.role as WorkspaceRole | null;

  const setAccountMode = useCallback((mode: AccountMode) => {
    setAccountModeState(mode);
    saveToStorage(STORAGE_KEY_MODE, mode);

    if (mode === "solo") {
      const soloWs = workspaces.find(ws => ws.type === "personal") || DEFAULT_SOLO_WORKSPACE;
      setActiveWorkspaceId(soloWs._id);
      saveToStorage(STORAGE_KEY_ACTIVE_WS, soloWs._id);
    } else if (mode === "team") {
      const teamWs = workspaces.find(ws => ws.type === "team");
      if (teamWs) {
        setActiveWorkspaceId(teamWs._id);
        saveToStorage(STORAGE_KEY_ACTIVE_WS, teamWs._id);
      }
    }
  }, [workspaces]);

  const switchToWorkspace = useCallback((workspaceId: string) => {
    const ws = workspaces.find(w => w._id === workspaceId);
    if (ws) {
      setActiveWorkspaceId(workspaceId);
      saveToStorage(STORAGE_KEY_ACTIVE_WS, workspaceId);
      const newMode = ws.type === "team" ? "team" : "solo";
      setAccountModeState(newMode);
      saveToStorage(STORAGE_KEY_MODE, newMode);
    }
  }, [workspaces]);

  const createTeamWorkspace = useCallback((name: string, description?: string) => {
    const newWs: WorkspaceInfo = {
      _id: `ws_team_${Date.now()}`,
      name,
      type: "team",
      description,
      membership: { role: "owner" },
    };
    const updated = [...workspaces, newWs];
    setWorkspaces(updated);
    saveToStorage(STORAGE_KEY_WORKSPACES, updated);
    setActiveWorkspaceId(newWs._id);
    saveToStorage(STORAGE_KEY_ACTIVE_WS, newWs._id);
    setAccountModeState("team");
    saveToStorage(STORAGE_KEY_MODE, "team");
  }, [workspaces]);

  const upgradeToTeam = useCallback(() => {
    const updated = workspaces.map(ws => {
      if (ws._id === activeWorkspaceId && ws.type === "personal") {
        return { ...ws, type: "team" as WorkspaceType, name: ws.name + " (Team)" };
      }
      return ws;
    });
    setWorkspaces(updated);
    saveToStorage(STORAGE_KEY_WORKSPACES, updated);
    setAccountModeState("team");
    saveToStorage(STORAGE_KEY_MODE, "team");
  }, [workspaces, activeWorkspaceId]);

  const contextValue = useMemo<WorkspaceContext>(() => ({
    activeWorkspace,
    workspaces,
    role,
    accountMode,
    isTeamMode: accountMode === "team",
    isSoloMode: accountMode === "solo",
    isOwner: role === "owner",
    isManager: role === "manager" || role === "owner",
    isMember: !!role,
    canManageTeam: role === "owner" || role === "manager",
    canManageBilling: role === "owner",
    activeWorkspaceId,
    isLoading: false,
    isAvailable: true,
    setAccountMode,
    switchToWorkspace,
    createTeamWorkspace,
    upgradeToTeam,
  }), [activeWorkspace, workspaces, role, accountMode, activeWorkspaceId, setAccountMode, switchToWorkspace, createTeamWorkspace, upgradeToTeam]);

  return (
    <WorkspaceCtx.Provider value={contextValue}>
      {children}
    </WorkspaceCtx.Provider>
  );
}

// ─── Stub hooks for Convex workspace mutations ───────────────────
// These are safe stubs that return no-op functions until the
// workspace tables are deployed to Convex. Components that import
// these (like TeamManagement) will work but mutations will be no-ops.

export function useWorkspaceMembers(_workspaceId: string | null) {
  return null;
}

export function useWorkspaceStats(_workspaceId: string | null) {
  return { memberCount: 0, clientCount: 0, activeProjectCount: 0, pendingInvoiceCount: 0 };
}

export function useInviteMember() {
  return async (_args: any) => {
    throw new Error("Workspace tables not deployed yet. Invite feature coming soon.");
  };
}

export function useRemoveMember() {
  return async (_args: any) => {
    throw new Error("Workspace tables not deployed yet. Remove member feature coming soon.");
  };
}

export function useUpdateMemberRole() {
  return async (_args: any) => {
    throw new Error("Workspace tables not deployed yet. Role update feature coming soon.");
  };
}

export function useCancelInvitation() {
  return async (_args: any) => {
    throw new Error("Workspace tables not deployed yet. Cancel invitation feature coming soon.");
  };
}

export function useConvertToTeamWorkspace() {
  return async (_args: any) => {
    throw new Error("Workspace tables not deployed yet. Convert to team feature coming soon.");
  };
}

export function useCreatePersonalWorkspace() {
  return async (_args: any) => {
    throw new Error("Workspace tables not deployed yet.");
  };
}

export function useCreateTeamWorkspace() {
  return async (_args: any) => {
    throw new Error("Workspace tables not deployed yet.");
  };
}

export function useSwitchWorkspace() {
  return async (_args: any) => {
    throw new Error("Workspace tables not deployed yet.");
  };
}

export function useUpdateWorkspace() {
  return async (_args: any) => {
    throw new Error("Workspace tables not deployed yet.");
  };
}

export function useAcceptInvitation() {
  return async (_args: any) => {
    throw new Error("Workspace tables not deployed yet.");
  };
}

export function useDeclineInvitation() {
  return async (_args: any) => {
    throw new Error("Workspace tables not deployed yet.");
  };
}

export function useTransferOwnership() {
  return async (_args: any) => {
    throw new Error("Workspace tables not deployed yet.");
  };
}

export function useDeleteWorkspace() {
  return async (_args: any) => {
    throw new Error("Workspace tables not deployed yet.");
  };
}

export function useActiveWorkspace() {
  return null;
}

export function useUserWorkspaces() {
  return null;
}

export function useMyInvitations() {
  return null;
}

export function useInvitationByToken(_token: string | null) {
  return null;
}
