import { useState, useEffect } from "react";

// ─── No-Auth Mode ────────────────────────────────────────────────
// Authentication is disabled. The app runs in "bypass" mode where
// every visitor is treated as an authenticated user with a mock
// profile. This lets the app work without Convex Auth while we
// build out the solo/agency multi-user features.

// A stable mock user so the rest of the app has something to render
const MOCK_USER = {
  _id: "mock_user_001" as any,
  name: "Freelancer User",
  email: "user@axia.app",
  image: "",
  hourlyRate: 25,
  subscriptionTier: "pro" as const,
  professionalBio: "",
  isAnonymous: false,
};

export function useAuth() {
  // Always authenticated in no-auth mode
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate a brief loading period so components that check isLoading
    // get a chance to mount before we claim to be authenticated
    const t = setTimeout(() => setIsLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  return {
    isLoading,
    isAuthenticated: true, // Always authenticated
    user: isLoading ? null : MOCK_USER,
    signIn: async (_provider?: string) => {
      /* no-op in no-auth mode */
    },
    signOut: async () => {
      /* no-op in no-auth mode */
    },
  };
}
